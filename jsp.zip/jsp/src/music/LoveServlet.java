package music;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javaBean.musicBean;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class LoveServlet
 */
@WebServlet("/LoveServlet")
public class LoveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoveServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String musicId=request.getParameter("musicId");
		String username=request.getParameter("username");
		PrintWriter out=response.getWriter();
		List <musicBean> provList = new ArrayList<musicBean>();
		String url="jdbc:mysql://localhost:3306/music";//���ݿ�
		url+="?user=root&password=123456";//�û��������룬������������ֵ������ʡ��password�ؼ���
		url+="&characterEncoding=utf-8";
		url+="&serverTimezone=Asia/Shanghai";
		Connection conn=null;
		ResultSet rs=null;
		Statement sql=null;
		response.setContentType("application/json;charset=utf-8");//text/plain
		JSONObject data =new JSONObject();
		System.out.println(!username.equals(""));
			if(username==null||!username.equals("")) {
			try {
				conn=DriverManager.getConnection(url);
				sql=conn.createStatement();
				String SQL="select * from loveform where username='"+username+"'"+" and musicId='"+musicId+"'";
				rs=sql.executeQuery(SQL);
				if(rs.next()) {
					String SQL1="DELETE from loveform where username='"+username+"'"+" and musicId='"+musicId+"'";
					sql.executeUpdate(SQL1);
					data.put("message","success");
					data.put("data","�ɹ��Ƴ�");
					out.print(data);
				}else {
					String SQL1="Insert loveform values('"+username+"','"+musicId+"')";
					System.out.print(SQL1);
					sql.executeUpdate(SQL1);
					data.put("message","success");
					data.put("data","�ɹ����ӵ�ϲ����");
					out.print(data);
				}
				conn=DriverManager.getConnection(url);
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			
			}else{
				data.put("message","error");
				out.print(data);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
