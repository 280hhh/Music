package music;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javaBean.UserBean;

/**
 * Servlet implementation class registerServlet
 */
@WebServlet("/registerServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String phone=request.getParameter("phone");
		String address=request.getParameter("address");
		String realname=request.getParameter("realname");
		request.setAttribute("username",username);
		request.setAttribute("password",password);
		PrintWriter out=response.getWriter();
		//response.sendError(407, "Need authentication!!!" );
		if(username==null||password==null) {out.print("��ǰ��ֵΪ��");return;}
		String url="jdbc:mysql://localhost:3306/music";//���ݿ�
		url+="?user=root&password=123456";//�û��������룬������������ֵ������ʡ��password�ؼ���
		url+="&characterEncoding=utf-8";
		url+="&serverTimezone=Asia/Shanghai";
		Connection conn=null;
		try {
			conn=DriverManager.getConnection(url); 
			Statement sql=conn.createStatement();
			String sql1="select * from user";
			ResultSet rs=sql.executeQuery(sql1);
			int max=0;
			while(rs.next()){
				UserBean user=new UserBean();
				user.username=rs.getString("username");
				user.password=rs.getString("password");
				System.out.print("���ݿ�"+user.password);
				if(user.ID>max)max=user.ID;
				if(username.equals(user.username)){
					out.print("error1");
					return;
				}}
			String SQL2="insert into user values ('"+username+"','"+password+"')";
			System.out.print(SQL2);
			int rs2=sql.executeUpdate(SQL2);
			if(rs2==1) {out.print("success");}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		}
	
	}

}
