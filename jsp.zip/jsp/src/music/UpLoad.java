package music;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 * Servlet implementation class UpLoad
 */
@WebServlet("/UpLoad")
public class UpLoad extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpLoad() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		String musicname="";
		String singer="";
		String username="";
		String kind="";
		DiskFileItemFactory factoy=new DiskFileItemFactory();
		ServletFileUpload sfu=new ServletFileUpload(factoy);
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		//׼�����浽�ļ�
		Date day=new Date();    
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-ddHHmmss"); 
		try {
            List<FileItem> list=sfu.parseRequest(request);
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
				FileItem item = (FileItem)iterator.next();
				if (item.isFormField()) { // judge if it is not the file field
					String name = item.getFieldName(); // get the form's child name
					if (name.equals("musicname")) 
						musicname = item.getString("utf-8");
					else if (name.equals("singer")) 
						singer = item.getString("utf-8");
					else if (name.equals("username")) 
						username = item.getString("utf-8");
					else if (name.equals("kind"))
						kind = item.getString("utf-8");
						System.out.print(kind);
				} else {
					PrintWriter out =response.getWriter();//.append("Served at: ").append(request.getContextPath());
					String url="jdbc:mysql://localhost:3306/music";//���ݿ�
					url+="?user=root&password=123456";//�û��������룬������������ֵ������ʡ��password�ؼ���
					url+="&characterEncoding=utf-8";
					url+="&serverTimezone=Asia/Shanghai";
					Connection conn=null;
					Statement sql=null;
					conn=DriverManager.getConnection(url); 
					sql=conn.createStatement();
					response.setContentType("application/json;charset=utf-8");//text/plain
					String SQL="insert into musicform(path,username,musicname,singer,time,kindId) values ('"+df.format(day)+".mp3"+"','"+username+"','"+musicname+"','"+singer+"','"+sdf.format(day)+"','"+kind+"')";                            
					System.out.println(SQL);					
					sql.executeUpdate(SQL);
					String fName = df.format(day)+".mp3";  // get the file name
					int i = fName.lastIndexOf("\\");// fix the bug in ie
					fName = fName.substring(i + 1, fName.length());
					File path = new File("F:/mm/ymusic/src/assets/music");
					if (!path.isDirectory()) {
						path.mkdir();
					}
					String detail_attach_file = path +"/" +fName;
					try {
						if (fName != "") {
							item.write(new File(detail_attach_file));
							conn=DriverManager.getConnection(url);
							sql=conn.createStatement();
						}
					}catch (SQLException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					}
				}
			}} catch (Exception e) {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
