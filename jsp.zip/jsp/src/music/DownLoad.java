package music;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DownLoad
 */
@WebServlet("/DownLoad")
public class DownLoad extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DownLoad() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		String id=request.getParameter("id");
		String url="jdbc:mysql://localhost:3306/music";//���ݿ�
		url+="?user=root&password=123456";//�û��������룬������������ֵ������ʡ��password�ؼ���
		url+="&characterEncoding=utf-8";
		url+="&serverTimezone=Asia/Shanghai";
		String paths="";
		try {
			Connection conn = DriverManager.getConnection(url);
			Statement sql = conn.createStatement();
			String SQL="select * from musicform where musicId='"+id+"'";
			System.out.println(SQL);
			ResultSet rs = sql.executeQuery(SQL);
			while(rs.next()){
				paths=rs.getString("path");
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		String SQL="select * from user";
		String n="one.mp3";
		n=java.net.URLEncoder.encode(n, "UTF-8");
		response.setHeader("Content-Disposition", "attachment;filename="+n);
		File path = new File("F:/mm/ymusic/src/assets/music");
		System.out.println(id);
		FileInputStream in=new FileInputStream(path+"/"+paths);
		byte[] buf=new byte[1024];
		int len=in.read(buf,0,buf.length);
		ServletOutputStream out=response.getOutputStream();
		while(len>0) {
			out.write(buf, 0, len);
			len=in.read(buf,0,buf.length);
		}
		out.close();
		in.close(); 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
