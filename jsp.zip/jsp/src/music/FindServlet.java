package music;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import javaBean.musicBean;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class findServlet
 */
@WebServlet("/findServlet")
public class FindServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FindServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username=request.getParameter("username");
		String findText=request.getParameter("findText");
		int pageSize=Integer.parseInt(request.getParameter("pageSize"));
		int currentPage=Integer.parseInt(request.getParameter("currentPage"));
		String musicKind=request.getParameter("musicKind");
		List <musicBean> provList = new ArrayList<musicBean>();
		String url="jdbc:mysql://localhost:3306/music";//���ݿ�
		url+="?user=root&password=123456";//�û��������룬������������ֵ������ʡ��password�ؼ���
		url+="&characterEncoding=utf-8";
		url+="&serverTimezone=Asia/Shanghai";
		Connection conn=null;
		ResultSet rs=null;
		Statement sql=null;
		response.setContentType("application/json;charset=utf-8");//text/plain
		JSONObject data =new JSONObject();
		int total=0;
		PrintWriter out=response.getWriter();//.append("Served at: ").append(request.getContextPath());
			try {
			conn=DriverManager.getConnection(url);
			sql=conn.createStatement();
			String SQL="select * from musicform";
			rs=sql.executeQuery(SQL);
			while(rs.next()){
				musicBean newMusic=new musicBean();
				newMusic.musicname=rs.getString("musicname");
				newMusic.singer=rs.getString("singer");
				newMusic.path=rs.getString("path");
				newMusic.time=rs.getString("time");
				newMusic.username=rs.getString("username");
				provList.add(newMusic);
				total++;
			}
			List <musicBean> provList2 = new ArrayList<musicBean>();
			if(username!=null) {
			String SQL1="select * from loveform where username='"+username+"'";
			rs=sql.executeQuery(SQL1);
			while(rs.next()){
				musicBean newMusic=new musicBean();
				newMusic.musicId=Integer.parseInt(rs.getString("musicId"));
				provList2.add(newMusic);
				total++;
			}
			data.put("love",provList2);
			}else {
				data.put("love",provList2);	
			}
			if(findText==null){
				data.put("message","success");
				data.put("total",total);
				data.put("Array",provList);
				out.print(data);
				return;
			}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				try {
					rs.close();
					sql.close();
					conn.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} 
			try {
				List <musicBean> provList1 = new ArrayList<musicBean>();
				conn=DriverManager.getConnection(url);
			sql=conn.createStatement();
			String SQL2="";
			if(musicKind==null||musicKind.equals("")) {
				SQL2="select * from musicform where musicname like '%"+findText+"%' or "+"singer = '%"+findText +"%'";
			}else {
				SQL2="select * from musicform where ( musicname like '%"+findText+"%' or "+"singer = '%"+findText +"%' ) and kindId='"+musicKind+"'";
			}
				System.out.print(SQL2);
				rs=sql.executeQuery(SQL2);
			//������ҳ��
			int sum=0;
			rs.absolute(0);
			while(rs.next()) {
				sum++;
			}
			total=sum;
			System.out.print("total"+total);
			//ʵ�ַ�ҳ����
			rs.absolute((currentPage-1)*pageSize+1);
			for(int i=0;(i<pageSize);i++) {
				musicBean newMusic=new musicBean();
				newMusic.musicname=rs.getString("musicname");
				newMusic.singer=rs.getString("singer");
				newMusic.path=rs.getString("path");
				newMusic.time=rs.getString("time");
				newMusic.username=rs.getString("username");
				newMusic.musicId=Integer.parseInt(rs.getString("musicId"));
				provList1.add(newMusic);
				if(!rs.next()) {break;};
			}
			data.put("message","success");
			data.put("total",total);
			data.put("Array",provList1);
			out.print(data);
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			} 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
