package music;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class myFilter
 */
@WebFilter("/myFilter")
public class myFilter implements Filter {

    /**
     * Default constructor. 
     */
    public myFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
	    HttpServletResponse resp = (HttpServletResponse) response;
        // ���Ӳ�������������domain����
        resp.setContentType("text/html;charset=UTF-8");
        //���û��棬ȷ����ҳ��Ϣ����������
        resp.setHeader("Access-Control-Allow-Origin", "*");
        resp.setContentType("application/json;charset=UTF-8");
        resp.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
        resp.setHeader("Access-Control-Max-Age", "3600");
        resp.setHeader("Access-Control-Allow-Headers", "Origin, No-Cache, X-Requested-With, If-Modified-Since, Pragma, Last-Modified, Cache-Control, Expires, Content-Type, X-E4M-With,userId,token");//����������֧�ֵ�����ͷ��Ϣ�ֶ�
        resp.setHeader("Access-Control-Allow-Credentials", "false"); //���Ҫ��Cookie��������������Ҫָ��Access-Control-Allow-Credentials�ֶ�Ϊtrue;
        resp.setHeader("XDomainRequestAllowed","1");
        System.out.println("��ʼ����... "); 
		// pass the request along the filter chain
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
