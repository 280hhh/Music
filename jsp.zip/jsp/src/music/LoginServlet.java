package music;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;

import javaBean.UserBean;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class loginServlet
 */
@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String url="jdbc:mysql://localhost:3306/music";//���ݿ�
		url+="?user=root&password=123456";//�û��������룬������������ֵ������ʡ��password�ؼ���
		url+="&characterEncoding=utf-8";
		url+="&serverTimezone=Asia/Shanghai";
		Connection conn=null;
		ResultSet rs=null;
		PrintWriter out=response.getWriter();
		ObjectMapper om=new ObjectMapper();
		JSONObject data =new JSONObject();
		Statement sql=null;
		int pass=0;
		if(username==null||password==null||username.equals("")||password.equals("")) {out.print("error");return;}
		try {
			conn=DriverManager.getConnection(url); 
			sql=conn.createStatement();
			String SQL="select * from user";
			List <UserBean> provList = new ArrayList<UserBean>();
			rs=sql.executeQuery(SQL);
			UserBean user=new UserBean();
			while(rs.next()){
				user.username=rs.getString("username");
				user.password=rs.getString("password");
				System.out.print(password);
				provList.add(user);
				if(username.equals(user.username)){
					if(password.equals(user.password)){
						response.setStatus(200);
						data.put("user", user);
						data.put("message", "success");
						out.print(data);
						return ;
					}
				}
			}
			data.put("message","error");
			response.setStatus(200);
			out.print(data);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				rs.close();
				sql.close();
				conn.close();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		}
	}

}
