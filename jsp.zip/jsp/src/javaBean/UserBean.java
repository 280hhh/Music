package javaBean;

public class UserBean {
public String username="";
public String password="";
public String phone="";
public String address="";
public String realname="";
public int ID;
public String getusername() {
	return username;
}
public void setusername(String username) {
	this.username = username;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getRealname() {
	return realname;
}
public void setRealname(String realname) {
	this.realname = realname;
}
public int getID() {
	return ID;
}
public void setID(int iD) {
	this.ID = ID;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
}
