package javaBean;

public class musicBean {
public String musicname="";
public String singer="";
public String path="";
public String time="";
public String username="";
public int musicId=0;
boolean love=false;
public String getMusicname() {
	return musicname;
}
public void setMusicname(String musicname) {
	this.musicname = musicname;
}
public String getSinger() {
	return singer;
}
public void setSinger(String singer) {
	this.singer = singer;
}
public String getPath() {
	return path;
}
public void setPath(String path) {
	this.path = path;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public int getMusicId() {
	return musicId;
}
public void setMusicId(int musicId) {
	this.musicId = musicId;
}
public boolean isLove() {
	return love;
}
public void setLove(boolean love) {
	this.love = love;
}
}
