/*
 Navicat MySQL Data Transfer

 Source Server         : test
 Source Server Type    : MySQL
 Source Server Version : 80013
 Source Host           : localhost:3306
 Source Schema         : music

 Target Server Type    : MySQL
 Target Server Version : 80013
 File Encoding         : 65001

 Date: 31/12/2021 12:39:46
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for kindform
-- ----------------------------
DROP TABLE IF EXISTS `kindform`;
CREATE TABLE `kindform`  (
  `kindId` int(11) NOT NULL,
  `kindName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`kindId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kindform
-- ----------------------------
INSERT INTO `kindform` VALUES (1, '华语');
INSERT INTO `kindform` VALUES (2, '说唱');
INSERT INTO `kindform` VALUES (3, '流行');
INSERT INTO `kindform` VALUES (4, '民谣');

-- ----------------------------
-- Table structure for loveform
-- ----------------------------
DROP TABLE IF EXISTS `loveform`;
CREATE TABLE `loveform`  (
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `musicId` int(11) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of loveform
-- ----------------------------
INSERT INTO `loveform` VALUES ('qqqqq', 8);
INSERT INTO `loveform` VALUES ('qqqqq', 2);
INSERT INTO `loveform` VALUES ('chill', 8);

-- ----------------------------
-- Table structure for musicform
-- ----------------------------
DROP TABLE IF EXISTS `musicform`;
CREATE TABLE `musicform`  (
  `musicId` int(11) NOT NULL AUTO_INCREMENT,
  `musicname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `singer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `time` date NULL DEFAULT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `kindId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`musicId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of musicform
-- ----------------------------
INSERT INTO `musicform` VALUES (2, '童话镇', '陈一发儿', '2021-12-27164131.mp3', '2021-12-27', 'qqqqq', 4);
INSERT INTO `musicform` VALUES (5, '夏天的风', '温岚', '2021-12-27221606.mp3', '2021-12-27', 'qqqqq', 3);
INSERT INTO `musicform` VALUES (6, '被动(Live)', '徐佳莹,伍佰', '2021-12-27222142.mp3', '2021-12-27', 'qqqqq', 1);
INSERT INTO `musicform` VALUES (8, '做我的猫', '满舒克', '2021-12-27223510.mp3', '2021-12-27', 'qqqqq', 2);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`username`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('chill', '111111');
INSERT INTO `user` VALUES ('qqqqq', '123456');

SET FOREIGN_KEY_CHECKS = 1;
